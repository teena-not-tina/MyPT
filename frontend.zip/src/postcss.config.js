/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"], // 꼭 필요!
  theme: {
    extend: {},
  },
  plugins: [],
}
