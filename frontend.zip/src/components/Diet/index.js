// src/components/Diet/index.js
import React from 'react';
import FoodDetection from './components/FoodDetection';
// import './foodDetection.css'; // 기존 스타일도 같이 가져옴

const Diet = () => {
  return (
    <div className="diet-container">
      <FoodDetection />
    </div>
  );
};

export default Diet;
