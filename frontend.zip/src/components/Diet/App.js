// frontend/src/components/Diet/App.js
import React, { useState } from 'react';
import HomePage from './components/HomePage';
import FoodDetection from './components/FoodDetection'; // ✅ 직접 import
import EatingPage from './components/EatingPage';

const DietApp = () => {
  const [currentMode, setCurrentMode] = useState('home');

  const renderPage = () => {
    switch (currentMode) {
      case 'home':
        return (
          <HomePage
            onStartHomeCooking={() => setCurrentMode('homeCooking')}
            onStartEating={() => setCurrentMode('eating')}
          />
        );
      case 'homeCooking':
        return (
          <FoodDetection
            onGoHome={() => setCurrentMode('home')}
          />
        );
      case 'eating':
        return (
          <EatingPage
            onGoHome={() => setCurrentMode('home')}
          />
        );
      default:
        return (
          <HomePage
            onStartHomeCooking={() => setCurrentMode('homeCooking')}
            onStartEating={() => setCurrentMode('eating')}
          />
        );
    }
  };

  return (
    <div className="diet-app">
      {renderPage()}
    </div>
  );
};

export default DietApp;
