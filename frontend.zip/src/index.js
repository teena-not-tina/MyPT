// ✅ src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';

// ✅ Diet 컴포넌트를 components/Diet/index.js 에서 불러옴
import Diet from './components/Diet';
import './index.css'; // 스타일

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Diet />);
